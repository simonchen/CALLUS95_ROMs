+--------------------------------------------------------------+
| XXXXXX XX   XX XX  XX XX      XXXX  XXXXXX XX  XXXX  XX   XX |
| XX     XXX XXX XX  XX XX     XX  XX   XX   XX XX  XX XXX  XX |
| XXXX   XXXXXXX XX  XX XX     XXXXXX   XX   XX XX  XX XX X XX |
| XX     XX X XX XX  XX XX     XX  XX   XX   XX XX  XX XX  XXX |
| XXXXXX XX   XX  XXXX  XXXXXX XX  XX   XX   XX  XXXX  XX   XX |
| ------ --   --  ----  ------ --  --   --   --  ----  --   -- |
|  All you need for emulation gaming you can find at our page  |
|           +-------------------------------------+            |
|           |    http://pristavka.kulichki.net    |            |
|           +-------------------------------------+            |
|         - Emulators                - Gameboy                 |
|         - Roms                     - Nintendo                |
|         - History                  - Super Nintendo          |
|         - Top games                - Nintendo 64             |
|         - Search                   - Sega Genesis            |
|         - Links                    - Sega Saturn             |
|         - WWW Forum                - Sony Playstation        |
|         - Music                    - NEO-GEO                 |
|         - Utilities                - Impact                  |
|         - ...                      - Callus                  |
|                                                              |
|         More systems soon, daily updating! So visit us!      |
+--------------------------------------------------------------+
